NAME : AMOL SUDHIR VAGAD
EMAIL: vagad001@umn.edu
Student ID : 5292373

Instructions : 

Question 1 : 

The functions for the question are located in the getPyr.m and reconstructingImages.m files. The image can be tested from using the pyramids_test.m file.
The the Gaussian pyramid can be obtained by entering the type as "Gauss" and  Laplacian pyramid can be obtained by entering the type as "Laplace". Images at all the important images are displayed ater running the pyramids_test.m code. 

Question 2 : 
The functions for the question are located in the blendingImages.m, blendinghandeye and reconstructingImages.m files. The image can be tested from using the blend_test.m and Eye_on_hand.m files.All the ouput images are displayed at the required intervals. The most fina limage is the reconstructed image. 


Question 3 : 
The functions for the question are located in the mygradient.m file. The image can be tested from using the mygradient_test.m file.


Question 4 : 
The functions for the question are located in the mycanny.m file. The image can be tested from using the Canny_test.m file.

