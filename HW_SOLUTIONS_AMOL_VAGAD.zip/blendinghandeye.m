function output_image = blendinghandeye(I1, I2)
L1 = getPyr(I1, 'Laplace', 4);
L2 = getPyr(I2, 'Laplace', 4);

[p, q, r] = size(I1);
Mask = zeros(p,q,r);
h = imshow(I1);
ellipse = imellipse(gca,[149.295518207283 167.581232492997 52.3473389355742 22.2296918767507]);
Mask(:, :,1) = createMask(ellipse,h);
figure
imshow(Mask);
Mask(:, :, 2) = Mask(:,:,1);
Mask(:, :, 3) = Mask(:,:,1);
Mask = double(Mask);

gpyr = getPyr(Mask,'Gauss',4)
figure
imshow(gpyr{4})
figure
imshow(L1{4})
figure

imshow(L2{4})
gpyr
for i = 4:-1:1
    L{i} = gpyr{i}.*L1{i} + (1-gpyr{i}).*L2{i};
    figure
    imshow((uint8(L{i})));
    title('Laplace out');
end
L
%L{4} = gpyr{4}.*L1{4} + (255-gpyr{4}).*L2{4};

%figure
%imshow(L{4})
size(L)
output_image = reconstructingImage(L);
figure
imshow(uint8(output_image),[])
title('Reconstructed image');

end