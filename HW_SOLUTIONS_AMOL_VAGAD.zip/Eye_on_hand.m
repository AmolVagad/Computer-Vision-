clear 
clc
close all
I1 = imread('eye.jpg');
I1 = imresize(I1, [256 256]);
imshow(I1);
% [149.295518207283 167.581232492997 52.3473389355742 22.2296918767507]
I2 = imread('hand.jpg');
I2 = imresize(I2, [256 256]);
imshow(I2);

output = blendinghandeye(I1, I2);
figure
imshow(uint8(output));
title('Eye on hand');
