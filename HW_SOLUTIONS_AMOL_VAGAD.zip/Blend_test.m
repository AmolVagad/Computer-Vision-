clear
clc
close all

A = imread('apple.jpg');
B = imread('orange.jpg');


output_image = blendingImages(A, B);
%im = reconstructingImage(output_image);
%figure
%imshow(im);
%title('Blended image');
