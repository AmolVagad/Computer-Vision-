function [Gm, Gs] = mygradient(I_gray)



%Creating the kernel 
K=[-1 0 1; -1 0 1; -1 0 1];

%Creating the x gradient 
Ix = conv2(I_gray,K, 'same');
%Ix = uint8(Ix);

figure
subplot(2,2,1);
imshow(uint8(Ix), []);
title('The x gradient');

%Creating the y gradient 
Iy = conv2(I_gray,K', 'same');
%Iy = uint8(Iy);


subplot(2,2,2);
imshow(uint8(Iy),[]);
title('The y gradient');

% magnitude of the gradient 

Ixx = Ix.^2;
Iyy = Iy.^2;

Gm = sqrt(Ixx + Iyy);

subplot(2,2,3);
imshow(Gm, []);
title('The magnitude of Gradients');
% Direction of the gradient 

Gs = atan2(Ix, Iy);


subplot(2,2,4);
imshow(uint8(Gs), []);
title('The direction of Gradients');
end

