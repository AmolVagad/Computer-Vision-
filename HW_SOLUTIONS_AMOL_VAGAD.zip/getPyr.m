function pyr = getPyr(im, type, numlevels)



%Creating the kernel
X = (1/16)*[1 4 6 4 1];
H= X'*X;
s1 = 'Gauss';
s2 = 'Laplace';
Tf1 = strcmp(type, s1);
Tf2 = strcmp (type, s2);

if (Tf1 > 0 || Tf2 > 0)
    G{1} = im;
    for i = 2:numlevels
        im = G{i-1};
        %Smoothing with kernel
        I_red = im(:, :, 1);
        I_green = im(:, :, 2);
        I_blue = im(:, :, 3);
        % Blur the individual color channels.
        Ismooth_R = conv2(double(I_red),H, 'same');
        Ismooth_G = conv2(double(I_green), H, 'same');
        Ismooth_B = conv2(double(I_blue), H, 'same');
        % Recombine separate color channels into a single, true color RGB image.
        Ismooth= (cat(3, Ismooth_R , Ismooth_G, Ismooth_B));

        %Down-sampling the image by factor of 2
        I_down1 = Ismooth(1:2:end,1:2:end, :);
        G{i} = I_down1;
       % G{i} = uint8(G{i});
        figure
        
        imshow((G{i}));
        title('After downsampling by factor of 2 ');
    end
end
pyr = G;
figure
imshow(G{numlevels})
title('Gaussian final image')
if (Tf2 > 0)
   
    Hlap = 4*H;
    % upsampling
    L{numlevels} = G{numlevels};
    for i = numlevels-1:-1 : 1
        L{i} = (zeros(size(G{i})));
        disp('Entered loop');
        %Up sampling the image 
        L{i}(1:2:end, 1:2:end, :)=G{i+1};
        %figure
        %imshow(L{i})
        %Smoothing with kernel
        lap1_red = L{i}(:, :, 1);
        lap1_green = L{i}(:, :, 2);
        lap1_blue = L{i}(:, :, 3);
        %Blur the individual color channels.
        lap1_smooth_R = conv2(double(lap1_red),Hlap, 'same');
        lap1_smooth_G = conv2(double(lap1_green), Hlap, 'same');
        lap1_smooth_B = conv2(double(lap1_blue), Hlap, 'same');
        % Recombine separate color channels into a single, true color RGB image.
        lap1smooth= (cat(3, lap1_smooth_R , lap1_smooth_G, lap1_smooth_B));

        L{i} = double(G{i}) - double(lap1smooth);
        %L{i} = uint8(L{i});

        figure
        imshow((L{i}));
        title('The laplacian');
    end
    pyr = L;
end

end 

