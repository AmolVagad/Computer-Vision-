function output_image = blendingImages(I1, I2)
L1 = getPyr(I1, 'Laplace', 4);
L2 = getPyr(I2, 'Laplace', 4);

[p, q, r] = size(I1);
Mask = zeros(p,q,r);

for i =1:p
    for j = 1: q/2
        for k = 1:r
            Mask(i,j,k) = 1;
        end
    end
end

figure
imshow(Mask)
gpyr = getPyr(Mask,'Gauss',4)
figure
imshow(gpyr{4})
figure
imshow(L1{4})
figure

imshow(L2{4})
gpyr
for i = 4:-1:1
    L{i} = gpyr{i}.*L1{i} + (1-gpyr{i}).*L2{i};
    figure
    imshow(((L{i})));
    title('Laplace out');
end
L
%L{4} = gpyr{4}.*L1{4} + (255-gpyr{4}).*L2{4};

%figure
%imshow(L{4})
size(L)
output_image = reconstructingImage(L);
figure
imshow(uint8(output_image),[])
title('Reconstructed image');

end