clear
clc
close all
I =imread('house.jpg');

figure
imshow(I);
title('Original Image');
%Converting rgb image to gray scale

I_gray = rgb2gray(I);

figure
imshow(I_gray);
title('Gray scale image');

I_gray = rgb2gray(I);

figure
imshow(I_gray);
title('Gray scale image');

%Calling the function
[Gm, Gs] = mygradient(I_gray);

%Normalizing the kernel 
Kernel = [-1 0 1; -1 0 1; -1 0 1];


