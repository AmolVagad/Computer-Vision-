function I_thresh = mycanny(I)




%Apply Gaussian for smoothing 
H= fspecial('gaussian', 2, 2);
Is= conv2(I, H, 'same');
Is = uint8(Is);
figure
imshow(Is, []);
title('Smooth image');

% Creating the gradient images 

[Gm, Gs] = mygradient(Is);
Gs = rad2deg(Gs);
[m, n] = size(Gs);
I2 = zeros(m,n);
% Non maximal suppression
for i = 2:m-1
    for j = 2: m-1
        m1 = 22.5;
        m2 = 67.5;
        m3 = 112.5;
        m4 = 157.5;
        if ( Gs(i,j) >= 0 && Gs(i,j) < m1) || (Gs(i,j) > -m1 && Gs(i,j) <0)
            if Gm(i,j) < Gm(i,j+1) || Gm(i,j) < Gm(i,j-1)
                Gm(i,j) =0;
            end
        elseif ( Gs(i,j) >= m1 && Gs(i,j) < m2) || ( Gs(i,j) <= -m1 && Gs(i,j) > -m2)
            if Gm(i,j) < Gm(i-1, j+1) || Gm(i,j) < Gm(i+1, j-1)
                Gm(i,j) = 0;
            end
        
        elseif ( Gs(i,j) >= m2 && Gs(i,j) < m3) || ( Gs(i,j) <= -m2 && Gs(i,j) > -m3)
            if Gm(i,j) < Gm(i-1, j) || Gm(i,j) < Gm(i+1, j)
                Gm(i,j) = 0;
            end
        
        elseif ( Gs(i,j) >= m3 && Gs(i,j) < m4) || ( Gs(i,j) <= -m3 && Gs(i,j) > -m4)
            if Gm(i,j) < Gm(i-1, j-1) || Gm(i,j)< Gm(i+1, j+1)
                Gm(i,j) = 0;
            end
        
        elseif ( Gs(i,j) >= m4 || Gs(i,j) <= m4)
            if  Gm(i,j) < Gm(i,j+1) || Gm(i,j) < Gm(i,j-1)
                Gm(i,j) = 0;
            end
        end
        
        
        
    end
end
figure

imshow(uint8(Gm), []);
title('Non-max suppressed image');



 
 %Thresholding the image
I_thresh = zeros(m,n);
T_high = 100;
T_low = 10;
for i = 2: m-1
    for j = 2:n-1
        if (Gm(i,j) < T_low)
            Gm(i,j)= 0;
        elseif (Gm(i,j) >= T_low && Gm(i,j) <= T_high)
            if (Gm(i-1: i+1, j-1: j+1) < T_high)
                Gm(i,j) = 0;
            end
        end
        I_thresh(i,j) = Gm(i,j);
    end
end
figure
imshow(uint8(I_thresh), []);
title('Thresholding image');

% Result using the inbuilt MATLAB function 

Canny_out = edge(I, 'Canny');
figure
imshow((Canny_out));
title('With matlab function');
end
