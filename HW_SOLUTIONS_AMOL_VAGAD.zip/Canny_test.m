close all
clear 
clc

%Reading the input image
I = imread('coffman.jpg');
I = rgb2gray(I);
figure
imshow(I);
title('Original Image ');

I_thresh = mycanny(I);