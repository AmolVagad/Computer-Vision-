function I2= rotate_image(I1, theta, Po)
[n,m]=size(I1);
figure
imshow(I1);
Ix=uint8(zeros([600 600]));
Ix(n:2*n-1, m:2*m-1)=I1;
figure
imshow(Ix);
R=[cosd(theta) -sind(theta); sind(theta) cosd(theta)];

cx=Po(1);
cy=Po(2);
         
I2 = uint8(zeros([600 600]));
%Solution to  part 1 (a) 
tempx=zeros(n,m);
tempy=zeros(n,m);
for i=1:n
    for j=1:m
        Pc=[i,j]';
        Pcr=round(R*(Pc-Po)+Po);
        tempx(i,j)=Pcr(1,1)+Po(1);
        tempy(i,j)=Pcr(2,1)+Po(2);
        
         %I2(tempx(i,j), tempy(i,j))=I1(i,j);
           
         %{
        if (tempx(i,j)>0 && tempy(i,j)>0)
            
            I2(tempx(i,j), tempy(i,j))=I1(i,j);
            
        end
         %}
       
    end
end
%figure, 
%imshow(I2);
     





%Solution to part 1 (b)
%Finding corners of the rotated image

c1x=min(tempx(:));
c2x=max(tempx(:));
c1y=min(tempy(:));
c2y=max(tempy(:));
%Finding corners of the matrix housing the image
%Inverting the rotation of the image 

V = [0;0];
T = [R V;0 0 1];
t_form = affine2d(T);
Iw = imwarp(I1,t_form);
figure
imshow(Iw);         


for i=c1x:c2x
    for j=c1y:c2y
       
        PI2=[i;j];
        PI1= Po + R'*(PI2-Po);
        
         if(round(PI1(1))>n && round(PI1(1))<=n*2-1 &&...
               round(PI1(2))>n && round(PI1(2))<=n*2-1 && ...
                i>=1 && j>=1)
                % Perform Bilinear-Interpolation on origPoints
                %if(ceil(pointI1(1))>=1 && ceil(pointI1(2))>=1)
                    x = PI1(1);
                    y = PI1(2);
                    x1 = floor(PI1(1));
                    x2 = ceil(PI1(1));
                    y1 = floor(PI1(2));
                    y2 = ceil(PI1(2));
                    P1 = [x1,y1];
                    P2 = [x2,y1];
                    P3 = [x2,y2];
                    P4 = [x1,y2];

                    pixelVal = double((1/((x2-x1)*(y2-y1)))) *double( [x2 - x, x-x1] )* ...
                    double([Ix(P1(1),P1(2)), Ix(P3(1),P3(2)); Ix(P2(1),P2(2)), Ix(P4(1),P4(2))]) * ...
                    double([y2-y;y-y1]);
                    
                    I2(i,j) = uint8(pixelVal);
         end
    end
end
end

             
 