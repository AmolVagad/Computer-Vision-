clc
clear 
close all
%loading the data sets
load 'intrinsics.mat'
load 'teapot.mat'
% initializing the position vectors
t1=[0 -10 1]';
t2=[0 0 11]';
t3=[-10 0 1]';
t4=[4.5 -4.5 7.7782]';
%Generating Rotation matrices 
R1=[1 0 0; 0 cosd(-90) sind(-90); 0 -sind(-90) cosd(-90)];
R2=[1 0 0; 0 cosd(-90) sind(-90); 0 -sind(-90) cosd(-90)]*R1;
R3=R1*[cosd(90) 0 -sind(90); 0 1 0; sind(90) 0 cosd(90)];
R4=[0.707 0.5 -0.5 ; 0.707 -0.5 0.5; 0 -0.707 -0.707];
plot3(Str(1,:), Str(2,:), Str(3,:)); 
grid on
hold on
cam1 = plotCamera('Location',t1,'Orientation',R1,'Opacity',1, 'Label', 'Camera 1','AxesVisible',true);
cam2=plotCamera('Location',t2,'Orientation',R2,'Opacity',1,'Label','Camera 2','AxesVisible',true);
cam3=plotCamera('Location',t3,'Orientation',R3,'Opacity',1,'Label','Camera 3','AxesVisible',true);
cam4=plotCamera('Location',t4,'Orientation',R4,'Opacity',1,'Label','Camera 4','AxesVisible',true);




%Calling function to generate 4 different images for the cameras 
I1 =project_image(Str, K, R1,t1);
figure
imshow(I1);

I2 =project_image(Str, K, R2,t2);
figure
imshow(I2);

I3 =project_image(Str, K, R3,t3);
figure
imshow(I3);

I4 =project_image(Str, K, R4,t4);
figure
imshow(I4);



