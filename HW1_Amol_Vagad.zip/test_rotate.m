
clc
clear variables;
close all;
%Read the input image 
I1 = imread('cameraman.tif');

%Enter the angle in degrees
theta = input('Enter the angle in degrees');




%Enter the point of rotation in vector form
Po=input('Enter the point of rotation');


I2= rotate_image(I1, theta, Po);
figure
imshow(I2)


        

        
