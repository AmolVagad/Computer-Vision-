function I =project_image(Str, K, R,t) % Declaring the function 

%Creating the Transformation Matrix
T=[R t]; 
%Obtaining Inverse of the Transformation Matrix

invT=[R' -R'*t];

%Generating the Projection Matrix
Pi= K*invT;
%Generating initial black image
I = uint8(zeros(480,640));
[m,n]=size(Str);
%Homogenizing the Str Matrix to create 4 rows
Str =[Str;ones(1,n)];
%using the Projection matrix with the 3D point cloud data 
    for i=1:n
        %Multiplying Projection Matrix with every point of 3D cloud
        temp= Pi* Str(:,i);
        % Taking y/z and x/z
        I(ceil(temp(2)/temp(3)),ceil(temp(1)/temp(3)))=  255;
    end
    I=uint8(I);
    
end

