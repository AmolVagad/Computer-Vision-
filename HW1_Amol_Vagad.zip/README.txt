NAME : AMOL SUDHIR VAGAD
EMAIL: vagad001@umn.edu
Student ID : 5292373

Instructions : 

Question 1 : 

The function for the question is located in the rotate_image.m file. The image can be tested from using the test_rotate file. Enter the inputs for angle of rotation and coordinates for rotating the image. 
The outputs obtained will be an image that is rotated and the holes are removed using bi linear interpolation 
Note: My output afteer rotation gives image with holes. However, the output after bi-linear transformation leads to elimination of certain part of the image. 


Question 2: 

The function for the question is located in the project_image.m file. Here we are also loading the 2 .mat files. For running the function projtest.m file is used. This file gives output as 5 different images. the first image is the 3D plot which has the camera locations and the teapot in the world axis. The other 4 images are the images captured by the 4 cameras as the 4 different locations.  