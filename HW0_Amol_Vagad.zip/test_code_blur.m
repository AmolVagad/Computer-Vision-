clear;
clc;
close all;
I=imread('onion.png');%Fetch the image 
n=input('Enter order of the image=');%Take the order required
B=1/((n)^2)*ones(n,n);%Creating the average kernel 
output=Blur(I,n);%Calling the Blur function 
figure
imshow(output);%Display the blurred image 
Ig=rgb2gray(output);%Convert blur image to gray scale
figure
imshow(Ig);%Display gray svale blurred image
C=conv2(double(Ig),double(B),'same');%Apply the conv2 function
figure
imshow(uint8(C));%Display blurred image
