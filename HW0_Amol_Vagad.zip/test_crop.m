input_image=imread('onion.png');%Take the image
[m,n]=size(input_image);
start_x=input('Enter x co-ord');
start_y=input('Enter y co-ord');
width=input('Enter width');
height=input('Enter Height');
output_image=crop(input_image, start_x, start_y, width, height);%call the function
imshow(input_image)%Display original image
figure
imshow(output_image);%Display the cropped image

