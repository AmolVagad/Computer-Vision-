NAME: AMOL SUDHIR VAGAD
STUDENT ID: 5292373
E-MAIL: vagad001@umn.edu 

For questions 1-5, the solutons and comments are provided in the Solution_HW0.pdf file. 
For questions 6 and 7, along with the function .m which are crop.m and Blur.m files I have also attached codes to implement the functions. To check the functions, only run the test_crop.m and and test_code_blur.m files. 
For test_crop.m :
Following inputs need to be provided:
start_x= x co-ord
start_y= y co-ord
width
height
After entering these inputs we can obtain the cropped figure according to the inputs provided. 
For test_code_blur.m:
Just enter the required value of �n� 
The output will provide RGB blurred image, grayscale blurred image and a blurred image using �conv2 �function of MATLAB. 

