
function output=Blur(I1,n) %Creating the Blur function



[x,y,z]=size(I1);
for i=n:1:x-n;
    for j=n:1:y-n;
        for p=-n+1:1:n
            for q=-n+1:1:n
                 output_image(p+n,q+n,:)=I1(i+p,j+q,:);
            end
        end
        M1=mean(output_image);%Taking average of columns of the matrix
        M2=mean(M1,2);%Taking complete average of the matrix
        output(i,j,:)=M2;%Declaring the output image
        
    end
end

output=uint8(output);%Converting imgage to 8 but integer
imshow(output);%Display the Blurred image 
end
