
function output_image=crop(input_image, start_x, start_y, width, height)%Function declaration 


for i=start_x:1:width
    for j=start_y:1:height
        output_image(i+1-start_x,j+1-start_y,:)=input_image(i,j,:);%Declaring the cropped image
    end
end


end




